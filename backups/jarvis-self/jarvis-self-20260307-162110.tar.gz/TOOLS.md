# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## Google (gog)
- Account: jarvisbot1000@gmail.com
- Services: gmail, calendar, drive, contacts, docs, sheets
- Credentials: /home/cf/.openclaw/google-client-secret.json
- Set GOG_ACCOUNT=jarvisbot1000@gmail.com to avoid repeating --account flag

## Brave Search API
- Rate limit: max 1 request/second (Christian subscription limit). When doing multiple queries, throttle to <=1 rps.

## GitHub Strategy
- **Primary account for Coding Agent projects:** CFVibe (full access - create, push, delete)
- **Secondary account:** chrfra (limited access - read/write code only, NO delete)
- **Backup account:** jarvisbot1000-sudo (full access - receives CFVibe backups)
- **Use CFVibe by default** unless Christian explicitly says to use chrfra
- **All repos PRIVATE by default** (unless Christian says "public")
- **Backup script:** `/home/cf/.openclaw/workspace/scripts/github-backup-sync.sh`
- **Cron:** Daily at 3:00 AM (backs up CFVibe → jarvisbot1000-sudo)

## Kimi API Key Rotation
- **Keys:** 3 keys with automatic rotation
  - Primary: Created 2026-02-21, expires 2026-03-23
  - Alt 1: Created 2026-02-23, expires 2026-03-25
  - Alt 2: Created 2026-02-23, expires 2026-03-25
- **Rotation:** Automatic at 85% usage (weekly or 5-hour limit)
- **Fallback chain:** Primary → Alt1 → Alt2 → GPT-5.2
- **Warning:** 1 day before expiration
- **Script:** `/home/cf/.openclaw/workspace/scripts/kimi-key-rotation.sh`
- **Metadata:** `~/.openclaw/.kimi-keys/keys-metadata.json`
- **Log:** `~/.openclaw/logs/kimi-rotation.log`
- **Limits:** 100M weekly, 10M per 5-hour window per key
- **IMPORTANT:** GitHub CLI must be authenticated as `chrfra` (not just CFVibe)
  - Current: `gh auth status` shows CFVibe only
  - Need: `gh auth login` as chrfra, or `gh auth switch` to chrfra
- **Failure notification:** Check `/tmp/github-backup-failed` daily

## 21st.dev Access
- **MCP API Key:** Stored in environment (provided by Christian)
- **Persistent Chrome:** `~/.openclaw/browser/21st-dev-profile/`
- **Launch script:** `/home/cf/.openclaw/workspace/scripts/launch-21st-dev-chrome.sh`
- **Autostart:** Added to GNOME autostart
- **Methods (priority):**
  1. MCP (programmatic)
  2. Persistent Chrome (manual browse)
  3. Terminal/curl (emergency)

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

Add whatever helps you do your job. This is your cheat sheet.
