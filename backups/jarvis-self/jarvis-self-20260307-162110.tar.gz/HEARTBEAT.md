# HEARTBEAT.md

## Status: Cron-Based Automation Active

Most daily tasks now run via cron. Heartbeat checks should focus on:
- Failures/alerts from automated systems
- Ad-hoc checks when needed
- Pre-flight checks before resource-intensive operations

---

## Automated via Cron (No Heartbeat Action Needed)

### Morning Briefing
- **Schedule:** Daily at 08:00
- **Script:** `/home/cf/.openclaw/workspace/scripts/morning-briefing.sh`
- **Log:** `/home/cf/.openclaw/logs/morning-briefing.log`
- **Action:** Check log only if Christian reports missing briefing

### Backup and Self-Update
- **Schedule:** Daily at 03:00
- **Script:** `/home/cf/.openclaw/workspace/scripts/backup-and-update.sh`
- **Log:** `/home/cf/.openclaw/logs/backup-cron.log`
- **Includes:** OpenClaw self-update via built-in update or npm fallback

### GitHub Repo Backup
- **Schedule:** Daily at 03:30
- **Script:** `/home/cf/.openclaw/workspace/scripts/github-backup-sync.sh`
- **Log:** `/home/cf/.openclaw/logs/github-backup-cron.log`
- **Failure alert:** `/tmp/github-backup-failed`

---

## Heartbeat Checks (When Needed)

### Kimi API Key Rotation (Preflight before Kimi usage)
Run before doing work that will call Kimi:

```bash
$HOME/.openclaw/workspace/scripts/kimi-key-rotation.sh preflight
```

**What it does:**
- Checks current key usage (weekly and 5-hour limits)
- Rotates to next key if usage > 85% threshold
- Warns 1 day before key expiration

**Key Rotation Order:**
1. kimi-primary (created 2026-02-21, expires 2026-03-23)
2. kimi-alt-1 (created 2026-02-23, expires 2026-03-25)
3. kimi-alt-2 (created 2026-02-23, expires 2026-03-25)
4. Fallback: openai-codex/gpt-5.2

---

## Failure Detection

### GitHub Backup Failures
Check `/tmp/github-backup-failed` — if exists, notify Christian immediately.

### Morning Briefing Failures
Check `/home/cf/.openclaw/logs/morning-briefing-cron.log` for errors.

### General Backup Failures
Check `/home/cf/.openclaw/logs/backup-cron.log` for errors.

---

## Pre-Flight Checks

### GitHub CLI Auth
Verify before any GitHub-dependent operations:
```bash
gh auth status
```

**Required accounts:**
- CFVibe (primary development)
- jarvisbot1000-sudo (backup)
- chrfra (limited access)

---

## Keep this file minimal to skip unnecessary heartbeat API calls.
