# USER.md - About Christian

- **Name:** Christian
- **What to call them:** Christian
- **Pronouns:** he/him
- **Timezone:** Europe/Stockholm (GMT+1 winter, GMT+2 summer)
- **Location:** Mölnlycke, Sweden (house, currently renovating & extending)

## Personality

- **Process-driven:** Collects routines, checklists, heuristics, "if X then Y" rules
- **Outcome-driven:** Only cares about results - what do I get for what I put in?
- **Effort-vs-reward optimizer:** High-impact, low-effort wins. Ignores diminishing returns - redirects effort elsewhere
- **Emotionally detached:** Logic and reason over emotions. Finds others' emotional/erratic behavior confounding
- **Habits > motivation:** Systems beat willpower

## Work

- **Role:** UX Lead at Novacura (Jan 2022-present), Gothenburg
  - Manages design department in product org developing a low-code app dev platform
  - Budget, performance mgmt, talent mgmt, mentoring, lead UX designer
- **Education:** Computer Science (hasn't coded in ~10 years, now back via vibe coding)
- **Side project:** Vibe coding (tools/apps) to support work and personal productivity
- **Past:** Combitech (7.5yr UX), Volvo Group (HMI/UX feature lead), Saab (UX architect for C2 systems), LKAB (service design)
- **Wants:** Explain technical concepts with real examples - understands them but doesn't work with them daily
- **AI concern:** Staying ahead of AI's impact on UX/design job market, needs to know about shifts as they happen

## Goals

### Economy
- Maximize income & savings → global index funds → early retirement
- Follows rikatillsammans.se strategy (passive index investing, scientifically proven)
- Minimize expenses without sacrificing quality of life (cheaper electricity, tax advantages, deals)
- Automate life to focus on high-impact + free time

### Free Time
- Kite surfing (watches Kevin Langeree, Liam Whaley, wingfoil/kitefoil college, Get High with Mike, gowakefilms, Barefoot Surf)
- Stand-up paddleboarding / SUP (SUPboarder - 28 views)
- Cross-country skiing
- Cultural events & attractions (not concerts)
- Video games: PC gaming - Death Stranding, Expedition 33, Ghost of Tsushima
- Retro nostalgia: N64 (Zelda OoT, Mario 64, Mario Kart 64), Dreamcast (Shenmue), Deus Ex (huge fan - full OST listener)
- LOTR/Tolkien fan (Nerd of the Rings - 71 views)
- Urban exploration: The Proper People, Forgotten Buildings
- Plays retro games with childhood friend Mikael on weekends
- Interested in ROM hacks, fan games, kaizo Mario, new Zelda/Mario releases
- Deep Shenmue fan (subs: Shenmue Dojo, Shenmue Fans, Wandering Through Shenmue, Phantom River Stone, Virtua Bros, Shenmue 3 Topic)
- Speedrun/challenge content (Summoning Salt, Games Done Quick, Karl Jobst, Bismuth, Lowest Percent, Beck Abney, Kosmic)
- Warhammer/miniatures hobby (Warhammer, Squidmar Miniatures, MiniWarGaming, Majorkill, PLASMO, WesHammer)
- Camping/vanlife content (Everlanders, Kombi Life, CamperKanal, EXPLORER Magazin, Foresty Forest, Steve Wallis, 4x4PASSION, A Bus And Beyond, Mobile Dwellings)
- Sailing interest (Sailing SV Delos, Sailing in Scandinavia)

### Music Taste
- **#1 genre: R&B/Soul** - Summer Walker (most-watched artist overall), SZA, H.E.R., UMI, Muni Long, Jenevieve, Christian Kuria, Sabrina Claudio, SiR, Mac Ayres, Daniel Caesar, Alex Isley, Snoh Aalegra, Masego, RINI, Amber Mark, Bruno Mars, Doja Cat, Childish Gambino, Lucky Daye, Alina Baraz, Brent Faiyaz, Jorja Smith, Kehlani, Jhené Aiko, FKJ, Kaytranada, Tom Misch
- Prog metal: Dream Theater, Haken, Pain of Salvation, Therion, Evergrey, Kamelot, Liquid Tension Experiment
- Electronic: ODESZA, Bonobo, Tame Impala, Kraftwerk, ZHU, SG Lewis, Jungle, BAYNK, Calvin Harris
- Rock: Wolf Alice, Warpaint, The Offspring, Metallica, Queen
- **Lo-fi/chill is massive** (~60% of YouTube = background music): ChillHop, Purrple Cat, Coffee Date, sleepy fish, fern, Jokabi, Mikel, demon gummies, Dreamwave, saib, potsu, Kupla, kainbeats, idealism, L'Indécis, City Girl, Lofi Sleep Chill & Study
- Video game music: GlitchxCity (#3 most-watched), Dj Cutman, Ragitsu (Deus Ex OST - #2 most-watched!), insaneintherainmusic, Mewmore, SEGA SOUND TEAM, SQUARE ENIX MUSIC
- Christmas/holiday binge: Michael Bublé, Frank Sinatra, Nat King Cole, Dean Martin, Bing Crosby, Mariah Carey - seasonal tradition
- Swedish: Ted Gärdestad, Uno Svenningsson, Kent, Sapphire, Gyllene Tider
- New interest: Laufey, Sabrina Carpenter

### Content & Learning
- Science/explainers: Veritasium, Kurzgesagt, CGP Grey, Steve Mould, Computerphile, Real Engineering, Wendover Productions, Welch Labs
- Self-improvement/psychology: Andrew Huberman, Huberman Lab Clips, School of Life, Jocko Podcast, Sam Harris, Chris Williamson, Tom Bilyeu, Art of Improvement
- Business/entrepreneurship: Alex Hormozi, Leila Hormozi, Y Combinator, All-In Podcast, Lenny's Podcast, Alexander Pärleros
- Economics/finance: Mr. Money Mustache, Economics Explained, Money & Macro, RikaTillsammans
- UX/Design: NNgroup, The Design Project, DesignerUp, Chris Raroque, Miro, Nudgestock
- AI/Tech: Fireship, Matt Wolfe, AI Jason, The AI Advantage, OpenAI, Species (Documenting AGI), David Shapiro, AI In Context, Chase AI, ColdFusion, Marques Brownlee, Hardware Unboxed, **Digital Foundry** (551 views - top non-music channel), The Verge, SweClockers, Figure (humanoid robotics)
- Food/cooking: Chinese Cooking Demystified, Doobydobap, Jamie Oliver, 老饭骨, 小高姐, The Art of Cooking, kein Stress kochen, The Food Ranger, First We Feast, Glucose Revolution
- History/military: The Operations Room, Armchair Historian, Invicta, Tasting History, Luetin09, Tank Museum, Försvarsmakten, Banijay History
- Geopolitics/Sweden: RFU News, Försvarsmakten Inblick, Saab
- China content: Little Chinese Everywhere, Blondie in China, Xiaofei小飛, Walk East, Mandarin Blueprint, Team Wulinshu
- Urban planning: Not Just Bikes
- Space: Everyday Astronaut, SpaceX, Peter Diamandis
- Building/DIY: Home RenoVision DIY, Mitt liv som byggare, Kris Harbour Natural Building, Rickards Garage, colinfurze
- Negotiation/behavior: Chris Voss, People Who Read People
- Management: Management Courses - Mike Clayton

### Tech
- Gadget enthusiast, always looking for deals (price-sensitive, loves trying new tech cheap)
- Home automation: Alexa-controlled lights, routines (e.g. "Alexa, bedtime" kills all lights)
- Jacuzzi outside the house
- Interested in future tech, Iron Man Jarvis-style interaction
- Vibe coding apps to make life easier + potential business ideas
- VR interest (MRTV - Mixed Reality TV, SweViver)
- Follows Microsoft ecosystem (Microsoft, Microsoft Developer, Microsoft Events)
- Uses SketchUp for house planning (25 views on TheSketchUpEssentials)
- Learning Mandarin (Mandarin Blueprint) - for Yiying's family
- StarCraft fan (SC2HL, PiG Casts, ESL Archives)

### Health
- Follows scientifically verified health routines (only high-impact ones)
- Home gym: pull-ups, bench press, barbell/dumbbell work
- Wants more energy and to be more relaxed
- Migraines a few times/year - suspects stress + low sun/light sensitivity + sugar intake
- Interested in: coffee timing, eating windows, sleep optimization, training efficiency
- Mental health: avoid stress and overthinking
- Follows Jeff Nippard, Renaissance Periodization (evidence-based training)
- Interested in Wim Hof method, Glucose Revolution (blood sugar optimization)
- Huberman Lab for neuroscience-backed health protocols

### House
- Extending house, will rent part out
- Automated lighting throughout

### Camping
- Has a camping car - 2-3 longer trips/year + weekend trips within couple hours drive

## Family

- **Mother:** Monica (b. 1963)
- **Father:** Tomas (b. 1962)
- **Sister:** Johanna (b. 1993)
- **Girlfriend:** Yiying (together 7 years)
  - From China (Chengdu), grew up there, lived in Paris before Sweden
  - Studying to become undersköterska (nurse assistant) until ~mid 2027
  - Interests: crafts (weaves flowers, makes candles), animals, mushroom picking, fishing
  - Loves calm home life
  - They celebrate Chinese events, visit her family in Chengdu every couple years
  - They want to have a child or two

## How to Serve Christian

- **Be proactive:** Propose things aligned with his values, don't wait to be asked
- **Effort-vs-reward framing:** Always lead with impact relative to effort
- **No fluff:** Skip pleasantries, get to the point
- **Figure It Out directive:** "I can't" is not in vocabulary. Search, try, adapt, ship.
- **Explain technical concepts:** With real examples, since he understands but doesn't work with them daily
- **Cover all life areas:** Work productivity, AI tools, health, finances, home, relationships, free time
- **Slack DM preference:** Don't use Slack "reply to message"/threaded replies; send messages inline so they appear directly in the DM without requiring a click.
- **Action Rule:** Never ask Christian to do something I can do myself. If I can edit a file, run a command, or make a change → just do it. Only ask when I genuinely lack permission or it's destructive.
