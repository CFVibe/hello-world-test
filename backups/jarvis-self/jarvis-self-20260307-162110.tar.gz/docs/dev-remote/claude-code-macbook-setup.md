# Claude Code Remote Troubleshooting Setup (MacBook -> Byggfynd Host)

Goal: Let Claude Code on your Mac inspect and troubleshoot the app running on the host directly.

## 1) One-time on your MacBook (required)

### A. Generate SSH key (if you don't already have one)
```bash
ssh-keygen -t ed25519 -C "macbook-claude"
```
(Press enter through defaults.)

### B. Copy key to host user `cf`
```bash
ssh-copy-id cf@192.168.50.128
```

If `ssh-copy-id` is missing on Mac:
```bash
cat ~/.ssh/id_ed25519.pub | ssh cf@192.168.50.128 'mkdir -p ~/.ssh && cat >> ~/.ssh/authorized_keys && chmod 700 ~/.ssh && chmod 600 ~/.ssh/authorized_keys'
```

### C. Add SSH alias in `~/.ssh/config`
```sshconfig
Host byggfynd-host
  HostName 192.168.50.128
  User cf
  IdentityFile ~/.ssh/id_ed25519
  ServerAliveInterval 30
  ServerAliveCountMax 120
```

### D. Verify
```bash
ssh byggfynd-host 'hostname'
```

## 2) Ready commands Claude Code can run from your Mac

### Quick status
```bash
ssh byggfynd-host '/home/cf/.openclaw/workspace/scripts/remote/byggfynd-status.sh'
```

### Test env logs
```bash
ssh byggfynd-host '/home/cf/.openclaw/workspace/scripts/remote/byggfynd-logs-test.sh 300'
```

### Redeploy test env from latest main
```bash
ssh byggfynd-host '/home/cf/.openclaw/workspace/scripts/remote/byggfynd-redeploy-test.sh'
```

### Public stability check
```bash
ssh byggfynd-host '/home/cf/.openclaw/workspace/scripts/remote/byggfynd-stability.sh'
```

## 3) Suggested Claude Code workflow

1. Claude edits locally.
2. Push to `main`.
3. Auto-deploy runs.
4. Claude validates via:
   - `byggfynd-status.sh`
   - `byggfynd-logs-test.sh`
5. If broken, Claude fixes locally and pushes again.

## 4) Notes
- Live URLs:
  - Test: https://byggfynd-test.christianfransson.com
  - Prod: https://byggfynd.christianfransson.com
- Auto-deploy blocks prod if test fails.
