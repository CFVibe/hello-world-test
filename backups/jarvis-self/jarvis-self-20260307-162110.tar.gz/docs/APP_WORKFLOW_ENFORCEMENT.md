# APP_WORKFLOW_ENFORCEMENT.md - Hard Rules

## Pre-Flight Checklist (MANDATORY)
Before typing ANY code for an app:

1. [ ] Planning questions asked and Christian confirmed
2. [ ] PLANNING.md created with acceptance criteria
3. [ ] Design reviewed (mockup/wireframe if applicable)
4. [ ] QC plan documented (what tests, how verified)
5. [ ] Coding agent spawned (NOT main session implementation)

**If any unchecked → STOP. Do not proceed.**

## Implementation Rules (MANDATORY)

### Rule 1: Main Session Never Codes
- Main session = planning + orchestration only
- All code written by spawned sub-agent
- Exception: One-line fixes only (<5 lines)

### Rule 2: Test-First Deployment
1. Deploy to test environment
2. Run QC checklist on test
3. Fix issues in test
4. Only then deploy to production

### Rule 3: Headed Browser QC Required
For BOTH test and production:
- [ ] Load in headed browser
- [ ] Verify all assets load (JS, CSS, images all 200)
- [ ] Verify React/app renders (not just HTML)
- [ ] Screenshot saved for evidence
- [ ] Functional tests pass (click, upload, etc.)

### Rule 4: Evidence Before "Done"
Cannot declare app complete without:
- [ ] QC-EVIDENCE.md with test results
- [ ] Screenshots of both environments
- [ ] All acceptance criteria verified

## Violation Consequences
If I skip steps:
1. App will be broken (as demonstrated)
2. Christian loses trust
3. Work must be redone properly

## Self-Check Before "Done"
Ask:
- Did I use a coding agent? (If no → FAIL)
- Did I test in headed browser? (If no → FAIL)
- Did Christian approve the design? (If no → FAIL)
- Are test and prod identical? (If no → FAIL)

## Current Status
Last violation: 2026-02-23 (photo-counter app)
- Skipped planning confirmation
- Main session coded instead of agent
- No headed browser QC
- No design review

**Result:** Broken app, wasted time.
