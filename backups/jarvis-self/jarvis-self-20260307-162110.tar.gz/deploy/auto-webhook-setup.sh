#!/bin/bash
# auto-webhook-setup.sh - Automatically create GitHub webhooks on all chrfra repos
# Usage: ./auto-webhook-setup.sh

WEBHOOK_URL="https://deploy.christianfransson.com/webhook"
SECRET_FILE="/home/cf/.openclaw/.webhook-secret"
LOG_FILE="/home/cf/.openclaw/logs/webhook-setup.log"

mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Get webhook secret
get_secret() {
    cat "$SECRET_FILE" 2>/dev/null || echo ""
}

# Get chrfra token
get_token() {
    gh auth token --user chrfra 2>/dev/null || echo ""
}

# List all webhooks for a repo
list_webhooks() {
    local repo="$1"
    local token
    token=$(get_token)
    
    curl -s -H "Authorization: token $token" \
        -H "Accept: application/vnd.github.v3+json" \
        "https://api.github.com/repos/$repo/hooks" | \
        jq -r '.[].config.url' 2>/dev/null || echo ""
}

# Check if our webhook exists
webhook_exists() {
    local repo="$1"
    local hooks
    hooks=$(list_webhooks "$repo")
    
    echo "$hooks" | grep -q "$WEBHOOK_URL"
}

# Create webhook on repo
create_webhook() {
    local repo="$1"
    local token
    token=$(get_token)
    local secret
    secret=$(get_secret)
    
    log "  Creating webhook for $repo..."
    
    local response
    response=$(curl -s -X POST \
        -H "Authorization: token $token" \
        -H "Accept: application/vnd.github.v3+json" \
        "https://api.github.com/repos/$repo/hooks" \
        -d "{
            \"name\": \"web\",
            \"active\": true,
            \"events\": [\"push\"],
            \"config\": {
                \"url\": \"$WEBHOOK_URL\",
                \"content_type\": \"json\",
                \"secret\": \"$secret\"
            }
        }")
    
    if echo "$response" | grep -q '"id":'; then
        log "  ✅ Webhook created successfully"
        return 0
    else
        log "  ❌ Failed: $(echo "$response" | jq -r '.message' 2>/dev/null || echo "Unknown error")"
        return 1
    fi
}

# Get all chrfra repos
get_repos() {
    local token
    token=$(get_token)
    
    # Use simpler endpoint - get all repos for authenticated user
    curl -s -H "Authorization: token $token" \
        -H "Accept: application/vnd.github.v3+json" \
        "https://api.github.com/user/repos?per_page=100" | \
        jq -r '.[] | select(.owner.login == "chrfra") | .full_name' 2>/dev/null | \
        sort -u
}

# Main sync function
sync_webhooks() {
    log "=== Auto-Webhook Setup ==="
    
    local secret
    secret=$(get_secret)
    if [ -z "$secret" ]; then
        log "❌ Webhook secret not found"
        return 1
    fi
    
    local token
    token=$(get_token)
    if [ -z "$token" ]; then
        log "❌ chrfra token not available"
        return 1
    fi
    
    log "Fetching chrfra repos..."
    local repos
    repos=$(get_repos)
    
    if [ -z "$repos" ]; then
        log "⚠️ No repos found"
        return 1
    fi
    
    local total=0
    local existing=0
    local created=0
    local failed=0
    
    while IFS= read -r repo; do
        [ -z "$repo" ] && continue
        
        total=$((total + 1))
        log "[$total] Checking $repo..."
        
        if webhook_exists "$repo"; then
            log "  ✓ Webhook already exists"
            existing=$((existing + 1))
        else
            if create_webhook "$repo"; then
                created=$((created + 1))
            else
                failed=$((failed + 1))
            fi
            # Small delay to avoid rate limits
            sleep 1
        fi
    done <<< "$repos"
    
    log "=== Summary ==="
    log "Total repos: $total"
    log "Existing webhooks: $existing"
    log "Created: $created"
    log "Failed: $failed"
}

# Run
sync_webhooks
