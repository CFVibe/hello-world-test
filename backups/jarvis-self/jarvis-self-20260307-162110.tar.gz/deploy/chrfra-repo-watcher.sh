#!/bin/bash
# chrfra-repo-watcher.sh - Auto-discover all chrfra repos and watch for new ones
# Usage: ./chrfra-repo-watcher.sh [once|loop]

set -e

WATCH_FILE="/home/cf/.openclaw/deploy/watch-list.txt"
STATE_FILE="/home/cf/.openclaw/deploy/chrfra-repos.json"
LOG_FILE="/home/cf/.openclaw/logs/chrfra-watcher.log"

mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$STATE_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# Initialize state
init_state() {
    if [ ! -f "$STATE_FILE" ]; then
        echo '[]' > "$STATE_FILE"
    fi
}

# Get all chrfra repos
get_chrfra_repos() {
    log "Fetching chrfra repos from GitHub..."
    
    # Switch to chrfra account
    export GH_TOKEN=$(gh auth token --user chrfra 2>/dev/null || echo "")
    
    if [ -z "$GH_TOKEN" ]; then
        log "❌ Cannot get chrfra token"
        return 1
    fi
    
    # Get all repos (max 100, adjust if needed) - exclude forks
    curl -s -H "Authorization: token $GH_TOKEN" \
        -H "Accept: application/vnd.github.v3+json" \
        "https://api.github.com/user/repos?per_page=100&type=owner&affiliation=owner" | \
        jq -r '.[] | select(.owner.login == "chrfra" and .fork == false) | "\(.full_name) \(.default_branch)"' 2>/dev/null | \
        sort -u || \
        echo ""
}

# Sync repos to watch list
sync_repos() {
    log "=== Syncing chrfra repos ==="
    
    local repos
    repos=$(get_chrfra_repos)
    
    if [ -z "$repos" ]; then
        log "⚠️ No repos found or API error"
        return 1
    fi
    
    local new_count=0
    local existing_count=0
    
    # Read current watch list (exclude CFVibe entries)
    local current_watch
    current_watch=$(grep "^chrfra/" "$WATCH_FILE" 2>/dev/null || echo "")
    
    # Process each repo
    while IFS= read -r line; do
        [ -z "$line" ] && continue
        
        repo=$(echo "$line" | awk '{print $1}')
        branch=$(echo "$line" | awk '{print $2}')
        
        # Check if already in watch list
        if grep -q "^${repo} " "$WATCH_FILE" 2>/dev/null; then
            existing_count=$((existing_count + 1))
        else
            log "🆕 New repo detected: $repo ($branch)"
            echo "$repo $branch" >> "$WATCH_FILE"
            new_count=$((new_count + 1))
            
            # Trigger immediate deploy for new repo
            log "🚀 Triggering initial deploy..."
            /home/cf/.openclaw/deploy/auto-deploy.sh "$repo" "$branch" 2>&1 | tee -a "$LOG_FILE" || \
                log "⚠️ Initial deploy failed (will retry on next poll)"
        fi
    done <<< "$repos"
    
    # Save current state
    echo "$repos" | jq -R -s 'split("\n") | map(select(length > 0) | split(" ") | {repo: .[0], branch: .[1]})' > "$STATE_FILE"
    
    log "✅ Sync complete: $existing_count existing, $new_count new"
}

# Main loop
main() {
    init_state
    
    local mode="${1:-once}"
    
    while true; do
        sync_repos
        
        if [ "$mode" = "once" ]; then
            break
        fi
        
        log "=== Sleeping 5 minutes... ==="
        sleep 300
    done
}

main "$@"
