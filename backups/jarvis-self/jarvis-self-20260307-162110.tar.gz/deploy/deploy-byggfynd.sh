#!/usr/bin/env bash
set -euo pipefail

REPO_SLUG="${1:-chrfra/Byggfynd}"
BRANCH="${2:-main}"
APP_DIR="/home/cf/.openclaw/apps/byggfynd"
LOG_FILE="/home/cf/.openclaw/logs/auto-deploy.log"
STABILITY_CHECK="/home/cf/.openclaw/workspace/scripts/automation/verify-public-url-stability.sh"
LOCK_FILE="/tmp/byggfynd-deploy.lock"

exec 9>"$LOCK_FILE"
if ! flock -n 9; then
  echo "[$(date '+%F %T')] ⏭️ byggfynd deploy already running" | tee -a "$LOG_FILE"
  exit 0
fi

log() {
  echo "[$(date '+%F %T')] $1" | tee -a "$LOG_FILE"
}

log "=== Byggfynd Auto-Deploy: $REPO_SLUG ($BRANCH) ==="

if [ ! -d "$APP_DIR/.git" ]; then
  rm -rf "$APP_DIR"
  gh repo clone "$REPO_SLUG" "$APP_DIR" >>"$LOG_FILE" 2>&1
fi

cd "$APP_DIR"

git fetch origin >>"$LOG_FILE" 2>&1
git reset --hard "origin/$BRANCH" >>"$LOG_FILE" 2>&1
COMMIT=$(git rev-parse --short HEAD)
log "📦 Code synced: $COMMIT"

log "🧪 Deploying TEST..."
docker compose up -d --build byggfynd-test-db byggfynd-test-api byggfynd-test >>"$LOG_FILE" 2>&1

for i in {1..20}; do
  if curl -sf http://127.0.0.1:8092/api/health >/dev/null 2>&1; then
    break
  fi
  sleep 2
done

if ! curl -sf http://127.0.0.1:8092/api/health >/dev/null 2>&1; then
  log "❌ TEST health failed"
  exit 1
fi
log "✅ TEST health OK"

if [ -x "$STABILITY_CHECK" ]; then
  "$STABILITY_CHECK" "https://byggfynd-test.christianfransson.com" 6 1 >>"$LOG_FILE" 2>&1 || {
    log "❌ TEST public stability failed"
    exit 1
  }
fi

log "🚀 Deploying PROD..."
docker compose up -d --build byggfynd-prod-db byggfynd-prod-api byggfynd-prod >>"$LOG_FILE" 2>&1

for i in {1..20}; do
  if curl -sf http://127.0.0.1:8093/api/health >/dev/null 2>&1; then
    break
  fi
  sleep 2
done

if ! curl -sf http://127.0.0.1:8093/api/health >/dev/null 2>&1; then
  log "❌ PROD health failed"
  exit 1
fi
log "✅ PROD health OK"

if [ -x "$STABILITY_CHECK" ]; then
  "$STABILITY_CHECK" "https://byggfynd.christianfransson.com" 6 1 >>"$LOG_FILE" 2>&1 || {
    log "❌ PROD public stability failed"
    exit 1
  }
fi

cat > /home/cf/.openclaw/deploy/last-deploy-byggfynd.txt <<EOT
repo: $REPO_SLUG
branch: $BRANCH
commit: $COMMIT
time: $(date --iso-8601=seconds)
test: https://byggfynd-test.christianfransson.com
prod: https://byggfynd.christianfransson.com
status: success
EOT

log "=== ✅ Byggfynd deployment successful ($COMMIT) ==="
