#!/bin/bash
# deploy-listener.sh - Watch GitHub repos for new commits and auto-deploy
# Usage: ./deploy-listener.sh [once|loop]

set -e

WATCH_FILE="/home/cf/.openclaw/deploy/watch-list.txt"
STATE_FILE="/home/cf/.openclaw/deploy/last-commits.json"
LOG_FILE="/home/cf/.openclaw/logs/deploy-listener.log"
DEPLOY_SCRIPT="/home/cf/.openclaw/deploy/auto-deploy.sh"

mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$STATE_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# Initialize state file if not exists
init_state() {
    if [ ! -f "$STATE_FILE" ]; then
        echo '{}' > "$STATE_FILE"
    fi
}

# Get latest commit SHA for a repo
get_latest_commit() {
    local repo="$1"
    local branch="${2:-main}"
    
    # Try GH CLI first (uses stored auth)
    if gh api "repos/$repo/commits/$branch" --jq '.sha' 2>/dev/null; then
        return 0
    fi
    
    # Fallback to curl with token
    local token
    token=$(gh auth token 2>/dev/null || echo "")
    if [ -n "$token" ]; then
        curl -s -H "Authorization: token $token" \
            "https://api.github.com/repos/$repo/commits/$branch" | \
            jq -r '.sha // empty' 2>/dev/null
    fi
}

# Check if deployment needed
check_repo() {
    local repo="$1"
    local branch="${2:-main}"
    
    log "Checking $repo ($branch)..."
    
    local latest
    latest=$(get_latest_commit "$repo" "$branch")
    
    if [ -z "$latest" ] || [ "$latest" = "null" ]; then
        log "  ⚠️ Could not get latest commit (repo empty or no access?)"
        return 1
    fi
    
    local last_known
    last_known=$(jq -r ".[\"$repo\"] // empty" "$STATE_FILE" 2>/dev/null || echo "")
    
    if [ "$latest" = "$last_known" ]; then
        log "  ✓ Up to date ($latest)"
        return 0
    fi
    
    log "  🔄 New commit detected!"
    log "     Previous: ${last_known:-none}"
    log "     New: $latest"
    
    # Update state
    jq --arg repo "$repo" --arg sha "$latest" '.[$repo] = $sha' "$STATE_FILE" > "${STATE_FILE}.tmp" && \
        mv "${STATE_FILE}.tmp" "$STATE_FILE"
    
    # Trigger deploy
    log "  🚀 Triggering deployment..."
    if [ -x "$DEPLOY_SCRIPT" ]; then
        "$DEPLOY_SCRIPT" "$repo" "$branch" 2>&1 | tee -a "$LOG_FILE"
    else
        log "  ❌ Deploy script not found: $DEPLOY_SCRIPT"
    fi
}

# Main loop
main() {
    init_state
    
    if [ ! -f "$WATCH_FILE" ]; then
        log "❌ Watch list not found: $WATCH_FILE"
        log "Create it with format: owner/repo branch"
        exit 1
    fi
    
    local mode="${1:-once}"
    
    while true; do
        log "=== Scanning repos ($(date)) ==="
        
        while IFS= read -r line || [ -n "$line" ]; do
            # Skip comments and empty lines
            [[ "$line" =~ ^#.*$ ]] && continue
            [[ -z "$line" ]] && continue
            
            repo=$(echo "$line" | awk '{print $1}')
            branch=$(echo "$line" | awk '{print $2}')
            [ -z "$branch" ] && branch="main"
            
            check_repo "$repo" "$branch" || true
        done < "$WATCH_FILE"
        
        if [ "$mode" = "once" ]; then
            log "=== Single run complete ==="
            break
        fi
        
        log "=== Sleeping 5 minutes... ==="
        sleep 300
    done
}

main "$@"
