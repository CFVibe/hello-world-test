#!/bin/bash
# full-auto-deploy.sh - Complete automation: webhooks + deploy
# This runs on boot and sets up everything automatically

set -e

LOG_FILE="/home/cf/.openclaw/logs/full-auto-deploy.log"
mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "=== Full Auto-Deploy Startup ==="

# Step 1: Ensure webhooks exist on all chrfra repos
log "Step 1: Setting up webhooks on all chrfra repos..."
/home/cf/.openclaw/deploy/auto-webhook-setup.sh 2>&1 | tee -a "$LOG_FILE" || log "⚠️ Webhook setup had issues (continuing)"

# Step 2: Discover all chrfra repos
log "Step 2: Discovering chrfra repos..."
/home/cf/.openclaw/deploy/chrfra-repo-watcher.sh once 2>&1 | tee -a "$LOG_FILE" || log "⚠️ Repo discovery had issues (continuing)"

# Step 3: Start the deploy listener (watches for commits)
log "Step 3: Starting deploy listener..."
exec /home/cf/.openclaw/deploy/deploy-listener.sh "$@"
