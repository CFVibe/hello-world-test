#!/bin/bash
# webhook-receiver.sh - HTTP server to receive GitHub webhooks
# Usage: ./webhook-receiver.sh [port]
# Default port: 9000

PORT="${1:-9000}"
LOG_FILE="/home/cf/.openclaw/logs/webhook.log"
DEPLOY_SCRIPT="/home/cf/.openclaw/deploy/auto-deploy.sh"
SECRET_FILE="/home/cf/.openclaw/.webhook-secret"

mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
    echo "$1"
}

# Get or create webhook secret
get_secret() {
    if [ -f "$SECRET_FILE" ]; then
        cat "$SECRET_FILE"
    else
        # Generate random secret
        openssl rand -hex 32 > "$SECRET_FILE"
        chmod 600 "$SECRET_FILE"
        cat "$SECRET_FILE"
    fi
}

WEBHOOK_SECRET=$(get_secret)

# Verify GitHub signature
verify_signature() {
    local payload="$1"
    local signature="$2"
    
    if [ -z "$signature" ]; then
        log "⚠️ No signature provided"
        return 1
    fi
    
    local computed
    computed=$(echo -n "$payload" | openssl dgst -sha256 -hmac "$WEBHOOK_SECRET" | sed 's/^.* //')
    
    if [ "sha256=$computed" = "$signature" ]; then
        return 0
    else
        log "❌ Signature mismatch"
        return 1
    fi
}

# Parse GitHub webhook payload
parse_payload() {
    local payload="$1"
    
    # Extract repo full_name
    local repo
    repo=$(echo "$payload" | jq -r '.repository.full_name // empty' 2>/dev/null)
    
    # Extract branch (ref format: refs/heads/main)
    local branch
    branch=$(echo "$payload" | jq -r '.ref // empty' | sed 's|refs/heads/||' 2>/dev/null)
    
    # Only process chrfra repos
    if [[ "$repo" != chrfra/* ]]; then
        log "⏭️ Ignoring non-chrfra repo: $repo"
        return 1
    fi
    
    echo "$repo $branch"
    return 0
}

# Handle incoming request
handle_request() {
    local method="$1"
    local path="$2"
    local headers="$3"
    local body="$4"
    
    # Only accept POST to /webhook
    if [ "$method" != "POST" ] || [ "$path" != "/webhook" ]; then
        echo "HTTP/1.1 404 Not Found"
        echo "Content-Type: text/plain"
        echo ""
        echo "Not Found"
        return
    fi
    
    # Get signature from headers
    local signature
    signature=$(echo "$headers" | grep -i "x-hub-signature-256:" | cut -d: -f2 | tr -d ' \r')
    
    # Verify signature
    if ! verify_signature "$body" "$signature"; then
        echo "HTTP/1.1 401 Unauthorized"
        echo "Content-Type: text/plain"
        echo ""
        echo "Unauthorized"
        return
    fi
    
    # Parse payload
    local parsed
    parsed=$(parse_payload "$body")
    if [ $? -ne 0 ]; then
        echo "HTTP/1.1 200 OK"
        echo "Content-Type: text/plain"
        echo ""
        echo "Ignored"
        return
    fi
    
    local repo branch
    repo=$(echo "$parsed" | cut -d' ' -f1)
    branch=$(echo "$parsed" | cut -d' ' -f2)
    
    log "🚀 Webhook received: $repo ($branch)"
    
    # Trigger deploy in background
    (
        sleep 1  # Small delay to let HTTP response return
        "$DEPLOY_SCRIPT" "$repo" "$branch" >> "$LOG_FILE" 2>&1
        log "✅ Deploy complete: $repo"
    ) &
    
    echo "HTTP/1.1 202 Accepted"
    echo "Content-Type: text/plain"
    echo ""
    echo "Deploy triggered for $repo"
}

# Simple HTTP server using netcat
start_server() {
    log "🌐 Starting webhook receiver on port $PORT"
    log "🔗 Webhook URL: http://$(hostname -I | awk '{print $1}'):$PORT/webhook"
    log "🔑 Secret: ${WEBHOOK_SECRET:0:16}..."
    
    while true; do
        # Read HTTP request
        { 
            read -r request_line
            method=$(echo "$request_line" | cut -d' ' -f1)
            path=$(echo "$request_line" | cut -d' ' -f2)
            
            headers=""
            content_length=0
            while IFS= read -r line; do
                line=$(echo "$line" | tr -d '\r')
                [ -z "$line" ] && break
                headers="${headers}${line}\n"
                if [[ "$line" =~ ^[Cc]ontent-[Ll]ength:\ *([0-9]+) ]]; then
                    content_length="${BASH_REMATCH[1]}"
                fi
            done
            
            body=""
            if [ "$content_length" -gt 0 ]; then
                body=$(head -c "$content_length")
            fi
            
            handle_request "$method" "$path" "$headers" "$body"
        } <<EOF | nc -l -p "$PORT" -q 1
EOF
    done
}

# Start with error handling
start_server 2>&1 | while read -r line; do
    log "$line"
done
