#!/bin/bash
# combined-watcher.sh - Run both chrfra auto-discovery and deploy listener

set -e

LOG_FILE="/home/cf/.openclaw/logs/combined-watcher.log"
mkdir -p "$(dirname "$LOG_FILE")"

echo "[$(date)] Starting combined watcher..." >> "$LOG_FILE"

# Step 1: Discover chrfra repos (adds new ones to watch-list)
echo "[$(date)] Discovering chrfra repos..." >> "$LOG_FILE"
/home/cf/.openclaw/deploy/chrfra-repo-watcher.sh once 2>> "$LOG_FILE" || true

# Step 2: Run deploy listener (checks all repos in watch-list for new commits)
echo "[$(date)] Starting deploy listener..." >> "$LOG_FILE"
exec /home/cf/.openclaw/deploy/deploy-listener.sh "$@"
