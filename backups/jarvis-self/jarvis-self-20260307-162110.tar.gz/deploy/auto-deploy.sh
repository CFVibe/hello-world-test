#!/bin/bash
# auto-deploy.sh - Deploy an app from GitHub to test → prod
# Usage: ./auto-deploy.sh owner/repo [branch]

set -e

REPO_SLUG="${1:-}"
BRANCH="${2:-main}"

if [ -z "$REPO_SLUG" ]; then
    echo "Usage: $0 owner/repo [branch]"
    exit 1
fi

APP_NAME_RAW=$(basename "$REPO_SLUG")

# App-specific deployment paths
REPO_SLUG_LC=$(echo "$REPO_SLUG" | tr '[:upper:]' '[:lower:]')
if [ "$REPO_SLUG_LC" = "chrfra/byggfynd" ]; then
    exec /home/cf/.openclaw/deploy/deploy-byggfynd.sh "$REPO_SLUG" "$BRANCH"
fi

# Docker requires lowercase image names
APP_NAME=$(echo "$APP_NAME_RAW" | tr '[:upper:]' '[:lower:]')
DEPLOY_BASE="/home/cf/.openclaw/apps"
APP_DIR="$DEPLOY_BASE/$APP_NAME"
LOG_FILE="/home/cf/.openclaw/logs/auto-deploy.log"

mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$DEPLOY_BASE"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "=== Auto-Deploy: $REPO_SLUG ($BRANCH) ==="

# Step 1: Clone or Pull
deploy_code() {
    log "📦 Step 1: Getting code..."
    
    if [ -d "$APP_DIR/.git" ]; then
        log "  Existing repo found, pulling latest..."
        cd "$APP_DIR"
        git fetch origin
        git reset --hard "origin/$BRANCH"
    else
        log "  Cloning fresh..."
        rm -rf "$APP_DIR"
        gh repo clone "$REPO_SLUG" "$APP_DIR"
        cd "$APP_DIR"
        git checkout "$BRANCH"
    fi
    
    log "  ✓ Code at $(git rev-parse --short HEAD)"
}

# Step 2: Read config or detect
read_config() {
    log "⚙️ Step 2: Reading config..."
    
    CONFIG_FILE="$APP_DIR/deploy-config.yml"
    
    if [ -f "$CONFIG_FILE" ]; then
        log "  Found deploy-config.yml"
        # Parse with simple grep/sed (no yq dependency)
        APP_NAME_CONFIG=$(grep "^app_name:" "$CONFIG_FILE" | cut -d: -f2 | xargs || echo "$APP_NAME")
        TEST_PORT=$(grep "^  test:" "$CONFIG_FILE" | cut -d: -f2 | xargs || echo "")
        PROD_PORT=$(grep "^  prod:" "$CONFIG_FILE" | cut -d: -f2 | xargs || echo "")
    else
        log "  No deploy-config.yml, auto-detecting..."
    fi
    
    # Auto-assign ports if not specified
    if [ -z "$TEST_PORT" ] || [ -z "$PROD_PORT" ]; then
        # Get next available ports starting from 8100
        local last_port
        last_port=$(ss -tlnp | grep LISTEN | grep "127.0.0.1:" | sed 's/.*127.0.0.1:\([0-9]*\).*/\1/' | sort -n | tail -1)
        if [ -z "$last_port" ] || [ "$last_port" -lt "8100" ]; then
            last_port=8100
        fi
        TEST_PORT=$((last_port + 1))
        PROD_PORT=$((last_port + 2))
    fi
    
    log "  Test port: $TEST_PORT"
    log "  Prod port: $PROD_PORT"
}

# Step 3: Build
deploy_build() {
    log "🔨 Step 3: Building..."
    
    cd "$APP_DIR"
    
    if [ -f "Dockerfile" ]; then
        log "  Building Docker image..."
        docker build -t "${APP_NAME}:latest" . 2>&1 | tail -5
    elif [ -f "docker-compose.yml" ]; then
        log "  Docker Compose build..."
        docker compose build 2>&1 | tail -5
    elif [ -f "package.json" ]; then
        log "  NPM build detected..."
        if [ -f "Dockerfile" ]; then
            docker build -t "${APP_NAME}:latest" .
        else
            log "  ⚠️ No Dockerfile, skipping build (will use npm start)"
        fi
    else
        log "  ⚠️ No Dockerfile or docker-compose.yml found"
        log "  Using simple nginx serve (static HTML)"
    fi
    
    log "  ✓ Build complete"
}

# Step 4: Deploy to Test
deploy_test() {
    log "🧪 Step 4: Deploying to TEST (port $TEST_PORT)..."
    
    cd "$APP_DIR"
    
    # Check if docker-compose exists
    if [ -f "docker-compose.yml" ]; then
        # Update ports in compose if needed
        sed -i "s/127\.0\.0\.1:[0-9]\+/127.0.0.1:${TEST_PORT}/g" docker-compose.yml 2>/dev/null || true
        docker compose up -d --build "${APP_NAME}-test" 2>&1 || \
            docker compose up -d --build 2>&1 || \
            docker run -d --name "${APP_NAME}-test" -p "127.0.0.1:${TEST_PORT}:3000" "${APP_NAME}:latest" 2>&1 || true
    else
        # Simple docker run
        docker rm -f "${APP_NAME}-test" 2>/dev/null || true
        docker run -d \
            --name "${APP_NAME}-test" \
            --restart unless-stopped \
            -p "127.0.0.1:${TEST_PORT}:3000" \
            "${APP_NAME}:latest" 2>&1 || \
        docker run -d \
            --name "${APP_NAME}-test" \
            --restart unless-stopped \
            -p "127.0.0.1:${TEST_PORT}:80" \
            -v "$APP_DIR:/usr/share/nginx/html:ro" \
            nginx:alpine 2>&1 || true
    fi
    
    sleep 3
    
    # Health check
    if curl -sf "http://localhost:${TEST_PORT}" >/dev/null 2>&1; then
        log "  ✓ TEST responding on port $TEST_PORT"
    else
        log "  ⚠️ TEST not responding yet (may need more time)"
    fi
}

# Step 5: QC Check
deploy_qc() {
    log "✅ Step 5: Running QC..."
    
    local test_url="http://localhost:${TEST_PORT}"
    local max_attempts=10
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        if curl -sf "$test_url" >/dev/null 2>&1; then
            log "  ✓ QC passed: $test_url responds 200"
            return 0
        fi
        log "  Attempt $attempt/$max_attempts: waiting for app..."
        sleep 5
        attempt=$((attempt + 1))
    done
    
    log "  ❌ QC failed: App not responding after ${max_attempts} attempts"
    return 1
}

# Step 6: Deploy to Prod
deploy_prod() {
    log "🚀 Step 6: Deploying to PROD (port $PROD_PORT)..."
    
    cd "$APP_DIR"
    
    if [ -f "docker-compose.yml" ]; then
        docker compose up -d --build "${APP_NAME}-prod" 2>&1 || \
            docker compose up -d --build 2>&1 || \
            docker run -d --name "${APP_NAME}-prod" -p "127.0.0.1:${PROD_PORT}:3000" "${APP_NAME}:latest" 2>&1 || true
    else
        docker rm -f "${APP_NAME}-prod" 2>/dev/null || true
        docker run -d \
            --name "${APP_NAME}-prod" \
            --restart unless-stopped \
            -p "127.0.0.1:${PROD_PORT}:3000" \
            "${APP_NAME}:latest" 2>&1 || \
        docker run -d \
            --name "${APP_NAME}-prod" \
            --restart unless-stopped \
            -p "127.0.0.1:${PROD_PORT}:80" \
            -v "$APP_DIR:/usr/share/nginx/html:ro" \
            nginx:alpine 2>&1 || true
    fi
    
    sleep 2
    
    if curl -sf "http://localhost:${PROD_PORT}" >/dev/null 2>&1; then
        log "  ✓ PROD responding on port $PROD_PORT"
    else
        log "  ⚠️ PROD not responding yet"
    fi
}

# Step 7: Setup DNS/Routing
deploy_dns() {
    log "🌐 Step 7: Setting up DNS and routing..."
    
    # Check if already registered
    if [ -f "/home/cf/.openclaw/ingress-rules.d/${APP_NAME}-prod.yml" ]; then
        log "  DNS already configured, skipping"
        return 0
    fi
    
    # Register with our automation
    if [ -x "/home/cf/.openclaw/scripts/register-app-ingress.sh" ]; then
        /home/cf/.openclaw/scripts/register-app-ingress.sh "$APP_NAME" "$PROD_PORT" "$TEST_PORT" 2>&1 || \
            log "  ⚠️ Ingress registration may have failed"
    else
        log "  ⚠️ register-app-ingress.sh not found"
    fi
    
    # Create DNS records
    cloudflared tunnel route dns 256c70c4-55b1-4880-a91d-d42f3684ddc9 "${APP_NAME}.christianfransson.com" 2>&1 || true
    cloudflared tunnel route dns 256c70c4-55b1-4880-a91d-d42f3684ddc9 "${APP_NAME}-test.christianfransson.com" 2>&1 || true
    
    log "  ✓ DNS configured"
    log "  Production: https://${APP_NAME}.christianfransson.com"
    log "  Test: https://${APP_NAME}-test.christianfransson.com"
}

# Step 8: Notify
deploy_notify() {
    log "📧 Step 8: Sending notification..."
    
    local message="🚀 Auto-Deploy Complete: $APP_NAME

Test: https://${APP_NAME}-test.christianfransson.com
Prod: https://${APP_NAME}.christianfransson.com

Commit: $(cd "$APP_DIR" && git rev-parse --short HEAD)
Branch: $BRANCH
Ports: Test=$TEST_PORT, Prod=$PROD_PORT"

    # Send to Telegram/Slack if configured
    echo "$message" > "/home/cf/.openclaw/deploy/last-deploy-${APP_NAME}.txt"
    
    log "  ✓ Notification saved"
}

# Main flow
main() {
    log "Starting deployment..."
    
    deploy_code
    read_config
    deploy_build
    deploy_test
    
    if deploy_qc; then
        deploy_prod
        deploy_dns
        deploy_notify
        log "=== ✅ DEPLOYMENT SUCCESSFUL ==="
    else
        log "=== ❌ DEPLOYMENT FAILED (QC) ==="
        log "App is running on TEST only for debugging"
        exit 1
    fi
}

main
