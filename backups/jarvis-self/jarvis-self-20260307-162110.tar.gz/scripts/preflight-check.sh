#!/bin/bash
# preflight-check.sh - Enforce GSD process before any app work
# This script must run before I start any app development

APP_NAME="$1"

if [ -z "$APP_NAME" ]; then
    echo "ERROR: No app name provided"
    exit 1
fi

echo "=== GSD PREFLIGHT CHECK ==="
echo "App: $APP_NAME"
echo ""

# Check 1: Planning document exists
if [ ! -f "/home/cf/.openclaw/apps/$APP_NAME/PLANNING.md" ]; then
    echo "❌ FAIL: PLANNING.md does not exist"
    echo "   Action: Create PLANNING.md with requirements confirmation"
    exit 1
fi
echo "✅ Planning document exists"

# Check 2: Design approved (Christian confirmation in chat)
echo "⚠️  CHECK: Has Christian confirmed the design/plan?"
echo "   This must be verified in chat history before proceeding"

# Check 3: Coding agent availability
echo "⚠️  CHECK: Is coding agent (Codex 5.3) available?"
if ! openclaw agents list | grep -q "codex"; then
    echo "   No coding agent available - main session CANNOT proceed"
    exit 1
fi

# Check 4: QC checklist prepared
if ! grep -q "QC Plan" "/home/cf/.openclaw/apps/$APP_NAME/PLANNING.md"; then
    echo "❌ FAIL: No QC plan in PLANNING.md"
    exit 1
fi
echo "✅ QC plan documented"

echo ""
echo "=== PREFLIGHT COMPLETE ==="
echo "If all checks pass, spawn coding agent to implement"
